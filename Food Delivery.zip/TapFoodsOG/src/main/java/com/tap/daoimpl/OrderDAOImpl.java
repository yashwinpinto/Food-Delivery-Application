package com.tap.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.OrderDao;
import com.tap.model.Order;
import com.tap.utility.DBConnection;

public class OrderDAOImpl implements OrderDao {
    
    private static final String INSERT_ORDER_QUERY = "INSERT INTO orders (user_id, restaurant_id, order_date, total_amount, status, payment_mode) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String GET_ORDER_QUERY = "SELECT * FROM orders WHERE order_id = ?";
    private static final String GET_ALL_ORDERS_QUERY = "SELECT * FROM orders";
    private static final String UPDATE_ORDER_QUERY = "UPDATE orders SET user_id = ?, restaurant_id = ?, order_date = ?, total_amount = ?, status = ?, payment_mode = ? WHERE order_id = ?";
    private static final String DELETE_ORDER_QUERY = "DELETE FROM orders WHERE order_id = ?";

    @Override
    public void addOrder(Order order) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(INSERT_ORDER_QUERY, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, order.getUserId());
            stmt.setInt(2, order.getRestaurantId());
            stmt.setDate(3, new java.sql.Date(order.getOrderDate().getTime()));
            stmt.setInt(4, order.getTotalAmount());
            stmt.setString(5, order.getStatus());
            stmt.setString(6, order.getPaymentMode());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                order.setOrderId(rs.getInt(1));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Order> getOrderById(int orderId) {
        Order order = null;
        
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(GET_ORDER_QUERY)) {
            
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                order = extractOrder(rs);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return (List<Order>) order;
    }

    @Override
    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        
        try (Connection connection = DBConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(GET_ALL_ORDERS_QUERY)) {
            
            while (rs.next()) {
                orders.add(extractOrder(rs));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return orders;
    }

    @Override
    public void updateOrder(Order order) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(UPDATE_ORDER_QUERY)) {
            
            stmt.setInt(1, order.getUserId());
            stmt.setInt(2, order.getRestaurantId());
            stmt.setDate(3, new java.sql.Date(order.getOrderDate().getTime()));
            stmt.setInt(4, order.getTotalAmount());
            stmt.setString(5, order.getStatus());
            stmt.setString(6, order.getPaymentMode());
            stmt.setInt(7, order.getOrderId());
            
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteOrder(int orderId) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(DELETE_ORDER_QUERY)) {
            
            stmt.setInt(1, orderId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static Order extractOrder(ResultSet rs) throws SQLException {
        return new Order(
            rs.getInt("order_id"),
            rs.getInt("usder_id"),
            rs.getInt("restaurant_id"),
            rs.getDate("order_date"),
            rs.getInt("total_amount"),
            rs.getString("status"),
            rs.getString("payment_mode")
        );
    }
    
    
    @Override
    public Order getLatestOrderByUserId(int userId) {
        Order order = null;
        String sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC LIMIT 1";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                order = new Order();
                order.setOrderId(rs.getInt("orderId"));
                order.setUserId(rs.getInt("userId"));
                order.setRestaurantId(rs.getInt("restaurantId"));
                order.setOrderDate(rs.getTimestamp("orderDate"));
                order.setTotalAmount(rs.getInt("totalAmount"));
                order.setPaymentMode(rs.getString("paymentMode"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return order;
    }

    public static List<Order> getOrdersByUser(int userId) {
        List<Order> orders = new ArrayList<>();

        String sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Order order = new Order();
                order.setOrderId(rs.getInt("orderId"));
                order.setUserId(rs.getInt("userId"));
                order.setRestaurantId(rs.getInt("restaurantId"));
                order.setOrderDate(rs.getTimestamp("orderDate"));
                order.setTotalAmount(rs.getInt("totalAmount"));
                order.setStatus(rs.getString("status"));
                order.setPaymentMode(rs.getString("paymentMode"));

                orders.add(order);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return orders;
    }


}
