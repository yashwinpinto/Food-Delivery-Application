package com.tap.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.OrderItemDao;
import com.tap.model.OrderItem;
import com.tap.utility.DBConnection;

public class OrderItemDAOImpl implements OrderItemDao {
    
    private static final String INSERT_ORDERITEM_QUERY = "INSERT INTO order_items (order_id, menu_id, quantity, total_price) VALUES (?, ?, ?, ?)";
    private static final String GET_ORDERITEM_QUERY = "SELECT * FROM order_items WHERE order_item_id = ?";
    private static final String GET_ORDERITEMS_BY_ORDER_QUERY = "SELECT * FROM order_items WHERE order_id = ?";
    private static final String UPDATE_ORDERITEM_QUERY = "UPDATE order_items SET order_id = ?, menu_id = ?, quantity = ?, total_price = ? WHERE order_item_id = ?";
    private static final String DELETE_ORDERITEM_QUERY = "DELETE FROM order_items WHERE order_item_id = ?";

    @Override
    public void addOrderItem(OrderItem orderItem) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(INSERT_ORDERITEM_QUERY, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, orderItem.getOrderId());
            stmt.setInt(2, orderItem.getMenuId());
            stmt.setInt(3, orderItem.getQuantity());
            stmt.setInt(4, orderItem.getTotalPrice());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                orderItem.setOrderItemId(rs.getInt(1));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public OrderItem getOrderItemById(int orderItemId) {
        OrderItem orderItem = null;
        
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(GET_ORDERITEM_QUERY)) {
            
            stmt.setInt(1, orderItemId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                orderItem = extractOrderItem(rs);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return orderItem;
    }

    @Override
    public List<OrderItem> getOrderItemsByOrderId(int orderId) {
        List<OrderItem> orderItems = new ArrayList<>();
        
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(GET_ORDERITEMS_BY_ORDER_QUERY)) {
            
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                orderItems.add(extractOrderItem(rs));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return orderItems;
    }

    @Override
    public void updateOrderItem(OrderItem orderItem) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(UPDATE_ORDERITEM_QUERY)) {
            
            stmt.setInt(1, orderItem.getOrderId());
            stmt.setInt(2, orderItem.getMenuId());
            stmt.setInt(3, orderItem.getQuantity());
            stmt.setInt(4, orderItem.getTotalPrice());
            stmt.setInt(5, orderItem.getOrderItemId());
            
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteOrderItem(int orderItemId) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(DELETE_ORDERITEM_QUERY)) {
            
            stmt.setInt(1, orderItemId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private OrderItem extractOrderItem(ResultSet rs) throws SQLException {
        return new OrderItem(
            rs.getInt("order_item_id"),
            rs.getInt("order_id"),
            rs.getInt("menu_id"),
            rs.getInt("quantity"),
            rs.getInt("total_price")
        );
    }
}
