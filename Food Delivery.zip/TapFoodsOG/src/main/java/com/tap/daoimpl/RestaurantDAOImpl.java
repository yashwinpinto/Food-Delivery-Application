package com.tap.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.RestaurantDao;
import com.tap.model.Restaurant;
import com.tap.utility.DBConnection;

public class RestaurantDAOImpl implements RestaurantDao {
    
    private static final String INSERT_RESTAURANT_QUERY = "INSERT INTO restaurant (name, address, phone, rating, cusine_type, is_active, eta, admin_user_id, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String GET_RESTAURANT_QUERY = "SELECT * FROM restaurant WHERE restaurant_id = ?";
    private static final String UPDATE_RESTAURANT_QUERY = "UPDATE restaurant SET name = ?, address = ?, phone = ?, rating = ?, cusine_type = ?, is_active = ?, eta = ?, admin_user_id = ?, image_path = ? WHERE restaurant_id = ?";
    private static final String DELETE_RESTAURANT_QUERY = "DELETE FROM restaurant WHERE restaurant_id = ?";
    private static final String GET_ALL_RESTAURANTS_QUERY = "SELECT * FROM restaurant";

    @Override
    public void addRestaurant(Restaurant restaurant) {
        try (Connection connection = DBConnection.getConnection(); 
             PreparedStatement stmt = connection.prepareStatement(INSERT_RESTAURANT_QUERY, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, restaurant.getName());
            stmt.setString(2, restaurant.getAddress());
            stmt.setString(3, restaurant.getPhone());
            stmt.setFloat(4, restaurant.getRating());
            stmt.setString(5, restaurant.getCusineType());
            stmt.setString(6, restaurant.getIsActive());
            stmt.setString(7, restaurant.getEta());
            stmt.setInt(8, restaurant.getAdminUserId());
            stmt.setString(9, restaurant.getImagePath());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                restaurant.setRestaurantId(rs.getInt(1));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Restaurant getRestaurantById(int restaurantId) {
        Restaurant restaurant = null;
        
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(GET_RESTAURANT_QUERY)) {
            
            stmt.setInt(1, restaurantId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                restaurant = extractRestaurant(rs);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return restaurant;
    }

    public static List<Restaurant> getAllRestaurants() {
        List<Restaurant> restaurants = new ArrayList<>();
        
        try (Connection connection = DBConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(GET_ALL_RESTAURANTS_QUERY)) {
            
            while (rs.next()) {
                restaurants.add(extractRestaurant(rs));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return restaurants;
    }

    @Override
    public void updateRestaurant(Restaurant restaurant) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(UPDATE_RESTAURANT_QUERY)) {
            
            stmt.setString(1, restaurant.getName());
            stmt.setString(2, restaurant.getAddress());
            stmt.setString(3, restaurant.getPhone());
            stmt.setFloat(4, restaurant.getRating());
            stmt.setString(5, restaurant.getCusineType());
            stmt.setString(6, restaurant.getIsActive());
            stmt.setString(7, restaurant.getEta());
            stmt.setInt(8, restaurant.getAdminUserId());
            stmt.setString(9, restaurant.getImagePath());
            stmt.setInt(10, restaurant.getRestaurantId());
            
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteRestaurant(int restaurantId) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(DELETE_RESTAURANT_QUERY)) {
            
            stmt.setInt(1, restaurantId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static Restaurant extractRestaurant(ResultSet rs) throws SQLException {
        return new Restaurant(
            rs.getInt("restaurantId"),
            rs.getString("name"),
            rs.getString("address"),
            rs.getString("phone"),
            rs.getFloat("rating"),
            rs.getString("cusineType"),
            rs.getString("isActive"),
            rs.getString("eta"),
            rs.getInt("adminUserId"),
            rs.getString("imagePath")
        );
    }
}