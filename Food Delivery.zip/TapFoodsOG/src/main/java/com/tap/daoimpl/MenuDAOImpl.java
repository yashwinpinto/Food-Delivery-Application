package com.tap.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tap.dao.MenuDao;
import com.tap.model.Menu;
import com.tap.utility.DBConnection;

public class MenuDAOImpl implements MenuDao {
    
    private static final String INSERT_MENU_QUERY = "INSERT INTO menu (restaurant_id, item_name, description, price, ratings, is_available, image_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String GET_MENU_QUERY = "SELECT * FROM menu WHERE menu_id = ?";
    private static final String GET_ALL_MENUS_QUERY = "SELECT * FROM menu";
    private static final String UPDATE_MENU_QUERY = "UPDATE menu SET restaurant_id = ?, item_name = ?, description = ?, price = ?, ratings = ?, is_available = ?, image_path = ? WHERE menu_id = ?";
    private static final String DELETE_MENU_QUERY = "DELETE FROM menu WHERE menu_id = ?";
    static final String FETCH_BY_ID = "SELECT * FROM menu WHERE menuId = ?";

    @Override
    public void addMenu(Menu menu) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(INSERT_MENU_QUERY, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, menu.getRestaurantId());
            stmt.setString(2, menu.getItemName());
            stmt.setString(3, menu.getDescription());
            stmt.setInt(4, menu.getPrice());
            stmt.setFloat(5, menu.getRatings());
            stmt.setBoolean(6, menu.getIsAvailable());
            stmt.setString(7, menu.getImagePath());
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                menu.setMenuId(rs.getInt(1));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Menu getMenuById(int menuId) {
        Menu menu = null;
        
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(GET_MENU_QUERY)) {
            
            stmt.setInt(1, menuId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                menu = extractMenu(rs);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return menu;
    }

    @Override
    public List<Menu> getAllMenus() {
        List<Menu> menus = new ArrayList<>();
        
        try (Connection connection = DBConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(GET_ALL_MENUS_QUERY)) {
            
            while (rs.next()) {
                menus.add(extractMenu(rs));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return menus;
    }

    @Override
    public void updateMenu(Menu menu) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(UPDATE_MENU_QUERY)) {
            
            stmt.setInt(1, menu.getRestaurantId());
            stmt.setString(2, menu.getItemName());
            stmt.setString(3, menu.getDescription());
            stmt.setInt(4, menu.getPrice());
            stmt.setFloat(5, menu.getRatings());
            stmt.setBoolean(6, menu.getIsAvailable());
            stmt.setString(7, menu.getImagePath());
            stmt.setInt(8, menu.getMenuId());
            
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteMenu(int menuId) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(DELETE_MENU_QUERY)) {
            
            stmt.setInt(1, menuId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Menu extractMenu(ResultSet rs) throws SQLException {
        return new Menu(
            rs.getInt("menuId"),
            rs.getInt("restaurantId"),
            rs.getString("itemName"),
            rs.getString("description"),
            rs.getInt("price"),
            rs.getFloat("ratings"),
            rs.getBoolean("isAvailable"),
            rs.getString("imagePath")
        );
    }
    
    @Override
    public Menu fetchOne(int menuId) 
    {
        try (Connection connection = DBConnection.getConnection();
        		PreparedStatement pstmt = connection.prepareStatement(FETCH_BY_ID))
        {
            pstmt.setInt(1, menuId);
            try (ResultSet resultSet = pstmt.executeQuery())
            {
                if (resultSet.next())
                {
                    return new Menu(
                            resultSet.getInt("menuId"),
                            resultSet.getInt("restaurantId"),
                            resultSet.getString("itemName"),
                            resultSet.getString("description"),
                            resultSet.getInt("price"),
                            resultSet.getFloat("ratings"),
                            resultSet.getBoolean("isAvailable"),
                            resultSet.getString("imagePath")
                    );
                }
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public List<Menu> getMenusByRestaurantId(int restaurantId) {
        List<Menu> menuList = new ArrayList<>();
        try {
            Connection con = DBConnection.getConnection();
            String query = "SELECT * FROM menu WHERE restaurantId = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, restaurantId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Menu menu = new Menu();
                menu.setImagePath(rs.getString("imagePath"));
                menu.setMenuId(rs.getInt("menuId"));
                menu.setRestaurantId(rs.getInt("restaurantId"));
                menu.setItemName(rs.getString("itemName"));
                menu.setDescription(rs.getString("description"));
                menu.setPrice(rs.getInt("price"));
                menuList.add(menu);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return menuList;
    }


}
