package com.tap.servlet;

import java.io.IOException;

import com.tap.dao.OrderDao;
import com.tap.model.Order;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/TrackOrderServlet")
public class TrackOrderServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = (int) request.getSession().getAttribute("userId"); // Adjust based on your session

        Order order = OrderDao.getLatestOrderForUser(userId);

        if (order != null) {
            request.setAttribute("status", order.getStatus());  // e.g., "Preparing"
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("trackOrder.jsp");
        dispatcher.forward(request, response);
    }
}
