package com.tap.servlet;


import java.io.IOException;
import java.util.List;

import com.tap.daoimpl.OrderDAOImpl;
import com.tap.model.Order;
import com.tap.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/orderHistory")
public class OrderHistoryServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {
	    
	    HttpSession session = request.getSession(false);
	    User user = (User) session.getAttribute("user");

	    if (user != null) {
	        int userId = user.getUserid();
	        List<Order> orders = OrderDAOImpl.getOrdersByUser(userId);
	        request.setAttribute("orders", orders);
	        request.getRequestDispatcher("orderHistory.jsp").forward(request, response);
	    } else {
	        response.sendRedirect("login.jsp");
	    }
	}

}

