package com.tap.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;

import com.tap.model.Cart;
import com.tap.model.CartItem;
import com.tap.utility.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/PlaceOrderServlet")
public class PlaceOrderServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null || cart.getItems().isEmpty()) {
            response.sendRedirect("cart.jsp");
            return;
        }

        String paymentMode = request.getParameter("paymentMode");
        Integer userIdObj = (Integer) session.getAttribute("userId");
        Integer restaurantIdObj = (Integer) session.getAttribute("restaurantId");

        if (userIdObj == null || restaurantIdObj == null) {
            response.sendRedirect("login.jsp"); // or any fallback
            return;
        }

        int userId = userIdObj.intValue();
        int restaurantId = restaurantIdObj.intValue();

        double totalAmount = cart.getTotal();

        Connection conn = null;
        PreparedStatement orderStmt = null;
        PreparedStatement itemStmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            // Insert into orders table
            String orderSql = "INSERT INTO orders (userId, restaurantId, orderDate, totalAmount, status, paymentMode) VALUES (?, ?, NOW(), ?, ?, ?)";
            orderStmt = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
            orderStmt.setInt(1, userId);
            orderStmt.setInt(2, restaurantId);
            orderStmt.setDouble(3, totalAmount);
            orderStmt.setString(4, "Placed");
            orderStmt.setString(5, paymentMode);
            orderStmt.executeUpdate();

            rs = orderStmt.getGeneratedKeys();
            int orderId = 0;
            if (rs.next()) {
                orderId = rs.getInt(1);
            }

            // Insert into order_items table
            String itemSql = "INSERT INTO order_items (orderId, menuId, quantity, totalPrice) VALUES (?, ?, ?, ?)";
            itemStmt = conn.prepareStatement(itemSql);

            for (Map.Entry<Integer, CartItem> entry : cart.getItems().entrySet()) {
                CartItem item = entry.getValue();
                int menuId = item.getItemId();
                int quantity = item.getQuantity();
                double totalPrice = quantity * item.getPrice();

                itemStmt.setInt(1, orderId);
                itemStmt.setInt(2, menuId);
                itemStmt.setInt(3, quantity);
                itemStmt.setDouble(4, totalPrice);
                itemStmt.addBatch();
            }

            itemStmt.executeBatch();

            session.removeAttribute("cart");
            request.setAttribute("orderId", orderId);
            request.getRequestDispatcher("OrderConfirmation.jsp").forward(request, response);


        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Order failed: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (orderStmt != null) orderStmt.close(); } catch (Exception ignored) {}
            try { if (itemStmt != null) itemStmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
    }
}
