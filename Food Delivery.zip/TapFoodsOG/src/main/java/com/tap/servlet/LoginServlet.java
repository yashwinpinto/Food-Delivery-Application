package com.tap.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/tap_foods";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "root";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD)) {

            	String sql = "SELECT * FROM user WHERE (username = ? OR email = ?) AND password = ?";
            	PreparedStatement stmt = conn.prepareStatement(sql);
            	stmt.setString(1, username); // input from form
            	stmt.setString(2, username); // again for email check
            	stmt.setString(3, password); // input from form


                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    int userId = rs.getInt("userId");
                    String name = rs.getString("username");

                    HttpSession session = request.getSession();
                    
                    session.setAttribute("userId", userId);
                    session.setAttribute("username", name);
                    

                    response.sendRedirect("home"); // or home.jsp or index.jsp
                } else {
                    response.sendRedirect("login.jsp?error=true");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp?error=true");
        }
    }
}
