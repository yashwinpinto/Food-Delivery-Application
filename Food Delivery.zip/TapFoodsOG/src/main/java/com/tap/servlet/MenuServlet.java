package com.tap.servlet;

import java.io.IOException;
import java.util.List;

import com.tap.daoimpl.MenuDAOImpl;
import com.tap.model.Menu;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/menu")
public class MenuServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String restIdParam = req.getParameter("restaurantId");

        // Validate restaurantId parameter
        if (restIdParam == null || restIdParam.isEmpty()) {
            resp.sendRedirect("home.jsp"); // or an error page
            return;
        }

        int restaurantId = Integer.parseInt(restIdParam);

        HttpSession session = req.getSession();
        Integer currentRestaurantId = (Integer) session.getAttribute("restaurantId");

        // If the selected restaurant is different from the current one in session
        if (currentRestaurantId == null || currentRestaurantId != restaurantId) {
            session.setAttribute("restaurantId", restaurantId);
            session.removeAttribute("cart"); // Clear cart when switching restaurants
        }

        try {
            MenuDAOImpl menuDao = new MenuDAOImpl();
            List<Menu> menus = menuDao.getMenusByRestaurantId(restaurantId);
            req.setAttribute("menus", menus);

            RequestDispatcher rd = req.getRequestDispatcher("menu.jsp");
            rd.forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("error.jsp");
        }
    }
}
