package com.tap.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.tap.daoimpl.RestaurantDAOImpl;
import com.tap.model.Restaurant;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/searchRestaurants")
public class SearchRestaurantsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String query = request.getParameter("query");

        List<Restaurant> allRestaurants = RestaurantDAOImpl.getAllRestaurants();
        List<Restaurant> filtered = new ArrayList<>();

        if (query != null && !query.trim().isEmpty()) {
            for (Restaurant r : allRestaurants) {
                if (r.getName().toLowerCase().contains(query.toLowerCase()) ||
                    r.getCusineType().toLowerCase().contains(query.toLowerCase())) {
                    filtered.add(r);
                }
            }
        }

        request.setAttribute("restaurants", filtered);
        request.getRequestDispatcher("home.jsp").forward(request, response);
    }
}
