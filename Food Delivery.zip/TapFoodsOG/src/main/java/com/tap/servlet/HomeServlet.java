package com.tap.servlet;

import java.io.IOException;
import java.util.List;

import com.tap.daoimpl.RestaurantDAOImpl;
import com.tap.model.Restaurant;
import com.tap.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/home")
public class HomeServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
		    // Default to guest user if not logged in
		    user = new User();
		    user.setUsername("Guest");
		    user.setUserid(0); // ID 0 to indicate guest
		    session.setAttribute("user", user);
		}
		request.setAttribute("user", user); // optional but helpful

		
		RestaurantDAOImpl restaurantDAO = new RestaurantDAOImpl();
	    List<Restaurant> restaurants = restaurantDAO.getAllRestaurants();

	    request.setAttribute("restaurants", restaurants);
	    request.getRequestDispatcher("home.jsp").forward(request, response);
	}

}
