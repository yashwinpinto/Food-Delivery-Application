package com.tap.dao;

import java.util.List;

import com.tap.model.Menu;

public interface MenuDao {
    void addMenu(Menu menu);
    static Menu getMenuById(int menuId) {
		// TODO Auto-generated method stub
		return null;
	}
    List<Menu> getAllMenus();
    void updateMenu(Menu menu);
    void deleteMenu(int menuId);
    Menu fetchOne(int userId);
    List<Menu> getMenusByRestaurantId(int restaurantId);

}
