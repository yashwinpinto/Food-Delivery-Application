package com.tap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tap.model.Order;
import com.tap.utility.DBConnection;

public interface OrderDao {
    void addOrder(Order order);
    static List<Order> getOrderById(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}
    List<Order> getAllOrders();
    void updateOrder(Order order);
    void deleteOrder(int orderId);
    Order getLatestOrderByUserId(int userId);

    
    
        public static Order getLatestOrderForUser(int userId) {
            Order order = null;
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY order_id DESC LIMIT 1";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    order = new Order();
                    order.setOrderId(rs.getInt("order_id"));
                    order.setStatus(rs.getString("status"));
                    // populate other fields if needed
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return order;
        }
        
        public static List<Order> getOrdersByUser(int userId) {
            List<Order> orders = new ArrayList<>();

            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "SELECT order_id, user_id, restaurant_id, order_date, total_amount, payment_mode " +
                     "FROM orders WHERE user_id = ? ORDER BY order_date DESC")) {

                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    Order order = new Order();
                    order.setOrderId(rs.getInt("order_id"));
                    order.setUserId(userId);
                    order.setRestaurantId(rs.getInt("restaurant_id"));
                    order.setOrderDate(rs.getTimestamp("order_date"));
                    order.setTotalAmount((int) rs.getDouble("total_amount"));
                    order.setPaymentMode(rs.getString("payment_mode"));

                    orders.add(order);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return orders;
        }
    

}
