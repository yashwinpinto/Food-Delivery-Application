package com.tap.dao;

import java.util.List;

import com.tap.model.Restaurant;

public interface RestaurantDao {
    void addRestaurant(Restaurant restaurant);
    Restaurant getRestaurantById(int restaurantId);
    static List<Restaurant> getAllRestaurants() {
		// TODO Auto-generated method stub
		return null;
	}
    void updateRestaurant(Restaurant restaurant);
    void deleteRestaurant(int restaurantId);
}
