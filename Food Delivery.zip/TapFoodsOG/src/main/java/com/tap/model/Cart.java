package com.tap.model;

import java.util.*;

public class Cart {
    private Map<Integer, CartItem> items;

    public Cart() {
        items = new HashMap<>();
    }

    public void addCartItem(CartItem item) {
        int itemId = item.getItemId();
        if (items.containsKey(itemId)) {
            CartItem existingCartItem = items.get(itemId);
            existingCartItem.setQuantity(existingCartItem.getQuantity() + item.getQuantity());
        } else {
            items.put(itemId, item);
        }
    }

    public void removeItem(int itemId) {
        items.remove(itemId);
    }

    public Map<Integer, CartItem> getItems() {
        return items;
    }

    public void clear() {
        items.clear();
    }

    public double getTotal() {
        double total = 0.0;
        for (CartItem item : items.values()) {
            total += item.getPrice() * item.getQuantity();
        }
        return total;
    }

    public void updateItemQuantity(int itemId, int quantity) {
        CartItem item = items.get(itemId);
        if (item != null) {
            item.setQuantity(quantity);
        }
    }

}
